(function($) {
    $(document).ready(function() {
	0.8
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	6
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	480
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	480
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	images
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	png
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	png
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	Animations Using the R Language
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	Animations generated in R version 3.3.0 (2016-05-03) using the package animation
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	FALSE
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	TRUE
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	FALSE
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	TRUE
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	TRUE
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
(function($) {
    $(document).ready(function() {
	images/Demostrate_CoDA_Dependency%d.png
	$('#Demostrate_CoDA_Dependency').scianimator({
	    'images': ['images/Demostrate_CoDA_Dependency1.png', 'images/Demostrate_CoDA_Dependency2.png', 'images/Demostrate_CoDA_Dependency3.png', 'images/Demostrate_CoDA_Dependency4.png', 'images/Demostrate_CoDA_Dependency5.png', 'images/Demostrate_CoDA_Dependency6.png'],
	    'width': 200,
	    'delay': 800,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
	$('#Demostrate_CoDA_Dependency').scianimator('play');
    });
})(jQuery);
